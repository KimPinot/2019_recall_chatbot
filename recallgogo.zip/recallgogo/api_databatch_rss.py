
import xml.etree.ElementTree as elemTree

import re
import json
import math
import datetime
import requests
import urllib.request
import urllib.error
import urllib.parse
from bs4 import BeautifulSoup
import pandas as pd

import feedparser
	
url = "https://www.consumer.go.kr/openapi/contents/index.do?serviceKey=LZPKCW8IFX&pageNo=1&cntPerPage=10&cntntsId=0301"

def crawl_rss(url) :
	d = feedparser.parse(url)
	#print(d.feed["content"])
	for e in d.entries :
		print(e.content)		
		
crawl_rss(url)
