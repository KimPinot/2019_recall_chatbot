import pymysql
import pandas as pd
from konlpy.tag import Mecab

mecab = Mecab()

hoststr = "localhost"
usrstr = "root"
passwordstr = "seoakey1009!"
dbstr = "CHATBOT"

company = "kisa"
system = "recall"

conn = pymysql.connect(host=hoststr, user=usrstr, password=passwordstr, db=dbstr, charset='utf8')
cursor = conn.cursor()

sql = "select * from RECALL_API_DATA "
    
df = pd.read_sql(sql, conn)

for index, row in df.iterrows():
	#infoId, classtype, cntntsId, infoDcSumry, infoDetailCn, infoOrigin, infoSj, infoUrl
	
	Question = row["infoSj"] #제목임
	Answer = row["infoDetailCn"]
	System_Sub_Gubun = row["classtype"] 
	System_User_Gubun = "ALL"
	Link_Gubun = row["infoId"]
	Link = row["infoUrl"]
	Insert_User_ID = row["infoOrigin"]
	
	if Question != "None" :
		sql2 = "insert into QNA_SET (Company, System, System_User_Gubun, System_Sub_Gubun, Question, Answer, Link_Gubun, Link, Insert_User_ID, Insert_Dt, Use_Yn) "
		sql2 +=" Values('"+company+"','"+system+"','"+System_User_Gubun+"','"+System_Sub_Gubun+"','"+Question+"','"+Answer+"',"
		sql2 +="'"+Link_Gubun+"','"+Link+"','"+Insert_User_ID+"',SYSDATE(),1) "
		cursor.execute(sql2)
		conn.commit()
	

sql = "select idx, System_User_Gubun, Question from QNA_SET "
sql += " where Company ='"+company+"' and System='"+system+"' "
    
df = pd.read_sql(sql, conn)

updateCnt = 0
duplicateCnt = 0	

for index, row in df.iterrows():
	Question = row["Question"]
	System_User_Gubun = row["System_User_Gubun"]
	idx_Qna_Set = row["idx"]

	malist = mecab.pos(Question)
	#형태소 분석된 명사 나열 정보 업데이트
	nouns = ""
	for word in malist:
		if word[1] in ["SL","NNG","NNB","NNP"]:
			nouns += word[0] + " "
	nouns = nouns[:-1]

	if len(nouns) > 0 :
		sql4 = "update QNA_SET set Question_Nouns='"+nouns.upper()+"' where Company='"+company+"' and System='"+system+"' and idx='"+str(idx_Qna_Set)+"'; "
		cursor.execute(sql4)
		conn.commit()
		print('업데이트 명사열 : '+nouns.upper())

	#형태소 분석된 값을 토큰에 저장시킴
	for word in malist:
		if word[1] in ["SL","NNG","NNB","NNP"]:
			Noun = word[0]
			#해당 명사 중복되어 있는지 체크
			sql = " select * from QNA_TOKEN where Company ='"+company+"' and System='"+system+"' and Noun='"+Noun+"' and idx_Qna_Set="+str(idx_Qna_Set)
			df = pd.read_sql(sql, conn)

			if df.shape[0] == 0:
				sql2 = " insert into QNA_TOKEN (Company, System, System_User_Gubun, Noun, idx_Qna_Set, Insert_Dt) "
				sql2 +=" Values('"+company+"','"+system+"','"+System_User_Gubun+"','"+Noun+"',"+str(idx_Qna_Set)+",SYSDATE()) "
				cursor.execute(sql2)
				conn.commit()
				print("추가된 형태소 : "+Noun)
				updateCnt = updateCnt + 1
			else : 
				duplicateCnt = duplicateCnt + 1

returnStr = "총 중복된 형태소 개수 : "+str(duplicateCnt)
returnStr += " / "
returnStr += "총 추가된 형태소 개수 : "+str(updateCnt)

print("총 중복된 형태소 개수 : "+str(duplicateCnt))
print("총 추가된 형태소 개수 : "+str(updateCnt))

cursor.close()
conn.close()