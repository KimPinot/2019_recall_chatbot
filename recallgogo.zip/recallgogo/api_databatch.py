import xml.etree.ElementTree as elemTree

import re
import json
import math
import datetime
import requests
import urllib.request
import urllib.error
import urllib.parse
from bs4 import BeautifulSoup
import pandas as pd


import pymysql

#의미 없는 단어 삭제를 통한 필요한 데이터 가져오기

def replace_all(text):
	dic = {"," : "", "'" : ""}
	for i, j in dic.items():
		text = text.replace(i,j)
	return text
	
hoststr = "localhost"
usrstr = "root"
passwordstr = "seoakey1009!"
dbstr = "CHATBOT"

#classtype = "자동차"
#cntntsId = "0301"
#pageNo = "1"
#serviceKey = "LZPKCW8IFX"

classtype = "공산품"
cntntsId = "0101"
pageNo = "1"
serviceKey = "E8J4FQWI3H"

conn = pymysql.connect(host=hoststr, user=usrstr, password=passwordstr, db=dbstr, charset='utf8')
cursor = conn.cursor()
    
	
url = "https://www.consumer.go.kr/openapi/contents/index.do?serviceKey="+serviceKey+"&pageNo="+pageNo+"&cntPerPage=100&cntntsId="+cntntsId
request = urllib.request.Request(url)
response = urllib.request.urlopen(request)
response_code = response.getcode()

print("status " + str(response_code))

body_info =""

if response_code is 200:
	response_body = response.read()
	body_info = response_body.decode('utf-8') 
	#print(body_info)

root = elemTree.fromstring(body_info)

#channel 자식 확인
#for child in root.find('channel').find('return'): print(child.tag)

childs = root.find('channel').find('return').findall('content') 

for i in range(0, len(childs)) : 
	print("---------"+str(i)+"------------------")
	print(childs[i][0].tag, ':', childs[i][0].text)
	print(childs[i][1].tag, ':', childs[i][1].text)
	print(childs[i][2].tag, ':', childs[i][2].text)
	print(childs[i][3].tag, ':', childs[i][3].text)
	print(childs[i][4].tag, ':', childs[i][4].text)
	print(childs[i][5].tag, ':', childs[i][5].text)
	print(childs[i][6].tag, ':', childs[i][6].text)
	
	infoId = childs[i][0].text
	classtype = classtype
	cntntsId = cntntsId
	if classtype == "자동차" : 
		infoDcSumry = replace_all(str(childs[i][2].text))
		infoDetailCn = replace_all(str(childs[i][3].text))
	else :
		infoDcSumry = replace_all(str(childs[i][3].text))
		infoDetailCn = replace_all(str(childs[i][2].text))
		
	infoOrigin = replace_all(childs[i][4].text)
	infoSj = replace_all(str(childs[i][5].text))
	infoUrl = childs[i][6].text
	
	sql2 = " insert into RECALL_API_DATA (infoId, classtype, cntntsId, infoDcSumry, infoDetailCn, infoOrigin, infoSj, infoUrl) "
	sql2 +=" Values('"+infoId+"','"+classtype+"','"+cntntsId+"','"+infoDcSumry+"','"+infoDetailCn+"','"+infoOrigin+"','"+infoSj+"','"+infoUrl+"'); "
	cursor.execute(sql2)
	conn.commit()
	print("로그 ok")

