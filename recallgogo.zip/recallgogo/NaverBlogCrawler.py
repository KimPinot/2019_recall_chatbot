#https://github.com/xotrs/naver-blog-crawler 참고

import re
import json
import math
import datetime
import requests
import urllib.request
import urllib.error
import urllib.parse
from bs4 import BeautifulSoup
import pandas as pd

naver_client_id = "KiK6l00dj30ghG2UhuYB"
naver_client_secret = "vI6bCXMTj2"


def naver_blog_crawling(search_blog_keyword, display_count, sort_type):
    #search_result_blog_page_count = get_blog_search_result_pagination_count(search_blog_keyword, display_count)
    return get_blog_post(search_blog_keyword, display_count, 1, sort_type)


def get_blog_search_result_pagination_count(search_blog_keyword, display_count):
    encode_search_keyword = urllib.parse.quote(search_blog_keyword)
    url = "https://openapi.naver.com/v1/search/blog?query=" + encode_search_keyword
    request = urllib.request.Request(url)

    request.add_header("X-Naver-Client-Id", naver_client_id)
    request.add_header("X-Naver-Client-Secret", naver_client_secret)

    response = urllib.request.urlopen(request)
    response_code = response.getcode()
    print("status " + str(response_code) )
    if response_code is 200:
        response_body = response.read()
        response_body_dict = json.loads(response_body.decode('utf-8'))

        if response_body_dict['total'] == 0:
            blog_pagination_count = 0
        else:
            blog_pagination_total_count = math.ceil(response_body_dict['total'] / int(display_count))

            if blog_pagination_total_count >= 1000:
                blog_pagination_count = 1000
            else:
                blog_pagination_count = blog_pagination_total_count

            print("키워드 " + search_blog_keyword + "에 해당하는 포스팅 수 : " + str(response_body_dict['total']))
            print("키워드 " + search_blog_keyword + "에 해당하는 블로그 실제 페이징 수 : " + str(blog_pagination_total_count))
            print("키워드 " + search_blog_keyword + "에 해당하는 블로그 처리할 수 있는 페이징 수 : " + str(blog_pagination_count))

        return blog_pagination_count


def get_blog_post(search_blog_keyword, display_count, search_result_blog_page_count, sort_type):
    encode_search_blog_keyword = urllib.parse.quote(search_blog_keyword)
    returnValue =""
    
    naver_df = pd.DataFrame(columns=['Gubun','Url','Title','Post_desc','Post_date'])
    for i in range(1, search_result_blog_page_count + 1):
        url = "https://openapi.naver.com/v1/search/blog?query=" + encode_search_blog_keyword + "&display=" + str(
            display_count) + "&start=" + str(i) + "&sort=" + sort_type

        request = urllib.request.Request(url)

        request.add_header("X-Naver-Client-Id", naver_client_id)
        request.add_header("X-Naver-Client-Secret", naver_client_secret)

        response = urllib.request.urlopen(request)
        response_code = response.getcode()
        print("status " + str(response_code) )
        if response_code is 200:
            response_body = response.read()
            response_body_dict = json.loads(response_body.decode('utf-8'))
            print(response_body_dict)
            print(len(response_body_dict['items']))
            for j in range(0, len(response_body_dict['items'])):
                blog_post_url = response_body_dict['items'][j]['link'].replace("amp;", "")

                get_blog_post_content_code = requests.get(blog_post_url)
                get_blog_post_content_text = get_blog_post_content_code.text
                remove_html_tag = re.compile('<.*?>')
                blog_post_title = re.sub(remove_html_tag, '', response_body_dict['items'][j]['title'])
                

                blog_post_description = re.sub(remove_html_tag, '',
                                                       response_body_dict['items'][j]['description'])
                blog_post_postdate = datetime.datetime.strptime(response_body_dict['items'][j]['postdate'],
                                                                        "%Y%m%d").strftime("%y.%m.%d")
                
                #naver_df.loc([str(2), blog_post_url, blog_post_title, blog_post_description, blog_post_postdate])
                print(naver_df.head())
                #naver_df[j] = ['Gubun' : str(2), "Url" : blog_post_url, "Title" : blog_post_title, "Post_desc" : blog_post_description, "Post_date" : blog_post_postdate]
                
                #naver_df.insert[j,"Gubun",str(2)]
                #naver_df.insert[j,"Url",blog_post_url]
                #naver_df.insert[j,"Title",blog_post_title]
                #naver_df.insert[j,"Post_desc",blog_post_description]
                #naver_df.insert[j,"Post_date",blog_post_postdate]

                print("url : " + blog_post_url)
                print("title : " + blog_post_title)
                print("post_desc : " + blog_post_description)
                print("post_date : " + blog_post_postdate)
                #print("블로거 이름 : " + blog_post_blogger_name)
                #print("포스팅 내용 : " + blog_post_full_contents)
                returnValue += "@" + str(2)
                returnValue += "@" + blog_post_url
                returnValue += "@" + blog_post_title
                returnValue += "@" + blog_post_description
                j += 1
            #return naver_df.to_json(orient='records')
            return returnValue


#if __name__ == '__main__':
#naver_blog_crawling("서울 아이 나들이", 5, "sim")
