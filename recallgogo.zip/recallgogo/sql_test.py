import pymysql

hoststr = "localhost"
usrstr = "root"
passwordstr = "seoakey1009!"
dbstr = "CHATBOT"


conn = pymysql.connect(host=hoststr, user=usrstr, password=passwordstr, db=dbstr, charset='utf8')
cursor = conn.cursor()
    

sql2 = " insert into QNA_LOG (User_ID, Insert_Dt) "
sql2 +=" Values('admin',sysdate()) "
cursor.execute(sql2)
conn.commit()
print("로그 ok")
