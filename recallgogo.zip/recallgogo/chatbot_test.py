# -*- coding: utf-8 -*-
from urllib import parse
import base64
import urllib.request
import json

company = "kisa"
system = "recall"
classgubun = parse.quote("ALL")
var1 = parse.quote("현대자동차")
user_gubun = parse.quote("소비자")

#url = "https://recall.run.goorm.io/callNLPJSON?company="+company+"&system="+system+"&classgubun="+classgubun+"&var1="+var1
#url = "https://recall.run.goorm.io/jsonTest?company="+company+"&system="+system+"&classgubun="+classgubun+"&var1="+var1
#url = "https://recall.run.goorm.io/getkey?user_gubun="+user_gubun

#소비자 요청
#infoId ="RCLL_000000000019416"
#user_id = "0xe292c994516c8b35c9743b260ec2086d1a47e14d"
#user_gubun = parse.quote("소비자")
#serialno = "chadeonumber_xxx"
#request_remarks = parse.quote("현대차 리콜 요청합니다.")
#status = "request"

#공급자 접수
#infoId ="RCLL_000000000019416"
#user_id = "33f2eeb60dae71613a2652f568aa5a7509bb9bcf"
#user_gubun = parse.quote("공급자")
#serialno = "chadeonumber_xxx"
#request_remarks = parse.quote("현대차 리콜 접수합니다.")
#status = "accept"

#공급자 수리중
#infoId ="RCLL_000000000019416"
#user_id = "33f2eeb60dae71613a2652f568aa5a7509bb9bcf"
#user_gubun = parse.quote("공급자")
#serialno = "chadeonumber_xxx"
#request_remarks = parse.quote("그랜저 세타 엔진 수리")
#status = "fixing"

#공급자 완료 요청
infoId ="RCLL_000000000019416"
user_id = "33f2eeb60dae71613a2652f568aa5a7509bb9bcf"
user_gubun = parse.quote("공급자")
serialno = "chadeonumber_xxx"
request_remarks = parse.quote("수리 완료되었습니다.확인요청드려요.")
status = "accept"

#소비자 승인완료
#infoId ="RCLL_000000000019416"
#user_id = "0xe292c994516c8b35c9743b260ec2086d1a47e14d"
#user_gubun = parse.quote("소비자")
#serialno = "chadeonumber_xxx"
#request_remarks = parse.quote("현대차 승인완료")
score = 5
score_remarks = parse.quote("수리 잘되었네요! 감사합니다.")
#status = "finish"


#url = "https://recall.run.goorm.io/recall_request?infoId="+infoId+"&user_id="+user_id+"&user_gubun="+user_gubun+"&serialno="+serialno+"&request_remarks="+request_remarks+"&status="+status
#url = "https://recall.run.goorm.io/recall_request?infoId="+infoId+"&user_id="+user_id+"&user_gubun="+user_gubun+"&serialno="+serialno+"&request_remarks="+request_remarks+"&status="+status+"&score="+str(score)+"&score_remarks="+score_remarks

url = "https://recall.run.goorm.io/nodejscall?infoId="+infoId+"&user_id="+user_id+"&user_gubun="+user_gubun+"&serialno="+serialno+"&request_remarks="+request_remarks+"&status="+status+"&score="+str(score)+"&score_remarks="+score_remarks

##url = "https://recall.run.goorm.io/recall_history_by_user_id?user_id="+user_id+"&user_gubun="+user_gubun

url_data = urllib.request.urlopen(url)
jsonString = url_data.read().decode("utf-8")

print(jsonString)
#json_data = data_process(url_data)
#print(json_data)

